package model;

public enum UserAction {
    upvoted, downvoted, unrelated;
}
