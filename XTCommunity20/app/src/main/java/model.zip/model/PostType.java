package model;

public enum PostType {
    Question, Answer;
}
